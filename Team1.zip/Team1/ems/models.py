from django.db import models

'''
# Create your models here.
class Admin(models.Model):
    username=models.CharField()
    password=models.CharField()
    edit_pass=models.CharField()



'''
class Employee(models.Model):
    name=models.CharField(max_length=30)
    address=models.CharField(max_length=40,default='zensar')
    staffid=models.IntegerField(primary_key=True)
    department1=models.CharField(max_length=30,default='kemba')
    phonenumber=models.IntegerField(default=180112233)

class Salary(models.Model):
    empname=models.CharField(max_length=30)
    department=models.CharField(max_length=30)
    staffid=models.IntegerField()
    salary=models.IntegerField()
    tech=models.CharField(max_length=30,default='python')
    work=models.IntegerField(default=2)

class Department(models.Model):
    empname=models.CharField(max_length=30)
    staffid=models.IntegerField()
    department=models.CharField(max_length=30)
    depid=models.IntegerField()
    date=models.CharField(max_length=30)
    checkin=models.CharField(max_length=30)
    checkout=models.CharField(max_length=30)
    
    
    
   
   


